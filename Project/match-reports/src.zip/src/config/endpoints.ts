// src/config/endpoints.ts
export const API_URLS = {
    catapultBase: "https://api.catapultsports.com",
    valdAuth: "https://security.valdperformance.com/connect/token",
    valdForceDecks: "https://api.valdperformance.com/forcedecks",
    valdNordBord: "https://api.valdperformance.com/nordbord",
    filmroomApi: "https://api.filmroom.us", // example
    // add as many as you like…
};

export type ApiUrls = typeof API_URLS;
