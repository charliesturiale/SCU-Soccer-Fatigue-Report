// src/lib/config.ts
import { Store } from "@tauri-apps/plugin-store";

let storeP: Promise<Store> | null = null;
async function getStore() {
    if (!storeP) storeP = Store.load("config.json"); // lives in app-data dir
    return storeP;
}

const KEYMAP = "apiKeys"; // we’ll keep all keys under this object

export async function listKeys(): Promise<string[]> {
    const store = await getStore();
    const map = (await store.get<Record<string, string>>(KEYMAP)) ?? {};
    return Object.keys(map).sort((a, b) => a.localeCompare(b));
}

export async function getKey(name: string): Promise<string | null> {
    const store = await getStore();
    const map = (await store.get<Record<string, string>>(KEYMAP)) ?? {};
    return map[name] ?? null;
}

export async function setKey(name: string, value: string): Promise<void> {
    const store = await getStore();
    const map = (await store.get<Record<string, string>>(KEYMAP)) ?? {};
    map[name] = value;
    await store.set(KEYMAP, map);
    await store.save();
}

export async function deleteKey(name: string): Promise<void> {
    const store = await getStore();
    const map = (await store.get<Record<string, string>>(KEYMAP)) ?? {};
    delete map[name];
    await store.set(KEYMAP, map);
    await store.save();
}

export async function exportConfig(): Promise<Record<string, string>> {
    const store = await getStore();
    return (await store.get<Record<string, string>>(KEYMAP)) ?? {};
}

export async function importConfig(obj: Record<string, string>) {
    const store = await getStore();
    await store.set(KEYMAP, obj);
    await store.save();
}
